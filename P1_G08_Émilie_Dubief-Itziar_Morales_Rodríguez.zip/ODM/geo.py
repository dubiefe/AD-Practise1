# Import fom __init__.py
import ODM

# GeoJSON and geo locator
import time
from geopy.exc import GeocoderTimedOut, GeocoderServiceError, GeocoderUnavailable
from geojson import Point

# Simple in-memory cache for address geocoding
_address_cache = {}

def getLocationPoint(address: str) -> Point:
    """
    Gets the coordinates of an address in geojson.Point format.
    Uses the geopy API to obtain the coordinates of the address.
    Be careful, the API is public and has a request limit, use sleeps.

    Parameters
    ----------
    address : str
        Full address from which to obtain coordinates

    Returns
    -------
    geojson.Point
        Coordinates of the address point
    """

    # INFO: Remove this comment to avoid rate limiting in testing
    #return Point([-3.703790, 40.416775])

    if address in _address_cache:
        return _address_cache[address]

    max_attempts = 5
    attempts = 0
    location = None

    # While the location hasn't been obtained and max number of attempts hasn't
    # been reached, keep trying to obtain location
    while location is None and attempts < max_attempts:
        try:
            time.sleep(1)
            # A user_agent is required to use the API
            # Use a random name for the user_agent
            geolocator = ODM.Nominatim(user_agent="Emilie_Itziar_AdvDB")
            location = geolocator.geocode(address)
        except GeocoderTimedOut:
            # Throw an exception if timeout is exceeded
            attempts += 1
            continue
        except (GeocoderServiceError, GeocoderUnavailable) as e:
            attempts += 1
            print(f"Geocoding service error: {e}")
            continue
        except Exception as e:
            print(f"Unexpected error during geocoding: {e}")
            attempts += 1
            continue

    if location is None:
        raise ValueError("No se pudieron obtener coordenadas")

    # Return coordinate points of location and store in cache
    point = Point([location.longitude, location.latitude])
    _address_cache[address] = point
    return point
